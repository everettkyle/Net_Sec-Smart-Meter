import pickle
from Crypto.PublicKey import RSA
from Crypto import Random
from Crypto.Cipher import AES

'''
@function generateMSG - this function puts the information in the correct format to be sent to the server
@param sender - name of sender
@param region - region that the meter is in
@param role   - role of the sender {SERVER, METER, WEBAPP}
@param action - action that is needed to be completed
@param data   - data being sent
@param IP     - callback IP
@param PORT   - callback port
'''
def generateMSG(sender, region, role, action, data, IP, PORT):
    payload = {'sender':sender,'region':region,'role':role,'action':action,'data':data,'ip':IP, 'port':PORT}
    payload = pickle.dumps(payload)
    return payload

def server_encrypt(data, privatekey, publickey):
    data = publickey.encrypt(data)
    return data

def server_decrypt(data, privatekey, publickey):
	data = privatekey.decrypt(data)
	return data

def meter_encrypt(data, privatekey, publickey):
	data = publickey.encrypt(data)
	return data

def meter_decrypt(data, privatekey, publickey):
	data = privatekey.decrypt(data)
	return data

#------------------------------------------------------------------------------------------------------------------

def aes_encrypt_payload(payload):
	aes_key = b'Michael loves hissy, Kyle loves ramen, Delton loves hissy and ramen'
	aes_cipher = AES.new(aes_key, AES.MODE_CBC)
	nonce = aes_cipher.nonce

	payload, tag = aes_cipher.encrypt_and_digest(payload)
	return payload

def aes_decrypt_payload(payload):
	aes_key = b'Michael loves hissy, Kyle loves ramen, Delton loves hissy and ramen'
	aes_cipher = AES.new(aes_key, AES.MODE_CBC)
	nonce = aes_cipher.nonce

	payload = aes_cipher.decrypt(payload)
	try:
		cipher.verify(tag)
		print("The message is authentic:", payload)
	except ValueError:
		print("Key incorrect or message corrupted.")
	return payload

def aes_encrypt_data(data):
	aes_key = b'Michael loves hissy, Kyle loves ramen, Delton loves hissy and ramen'
	aes_cipher = AES.new(aes_key, AES.MODE_CBC)
	nonce = aes_cipher.nonce

	data, tag = aes_cipher.encrypt_and_digest(data)
	return data

def aes_decrypt_data(data):
	aes_key = b'Michael loves hissy, Kyle loves ramen, Delton loves hissy and ramen'
	aes_cipher = AES.new(aes_key, AES.MODE_CBC)
	nonce = aes_cipher.nonce

	data = aes_cipher.decrypt(data)
	try:
		cipher.verify(tag)
		print("The message is authentic:", data)
	except ValueError:
		print("Key incorrect or message corrupted.")
	return data

def aes_encrypt_dataToSend(dataToSend):
	aes_key = b'Michael loves hissy, Kyle loves ramen, Delton loves hissy and ramen'
	aes_cipher = AES.new(aes_key, AES.MODE_CBC)
	nonce = aes_cipher.nonce

	dataToSend, tag = aes_cipher.encrypt_and_digest(dataToSend)
	return dataToSend

def aes_decrypt_dataToSend(dataToSend):
	aes_key = b'Michael loves hissy, Kyle loves ramen, Delton loves hissy and ramen'
	aes_cipher = AES.new(aes_key, AES.MODE_CBC)
	nonce = aes_cipher.nonce

	dataToSend = aes_cipher.decrypt(dataToSend)
	try:
		cipher.verify(tag)
		print("The message is authentic:", dataToSend)
	except ValueError:
		print("Key incorrect or message corrupted.")
	return dataToSend
